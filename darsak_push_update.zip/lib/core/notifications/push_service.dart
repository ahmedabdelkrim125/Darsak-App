import 'dart:async';
import 'package:dio/dio.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import '../../feat/notification/data/models/notification_type.dart';
import '../../feat/notification/data/notification_store.dart';
import '../di/service_locator.dart';
import '../session/app_session.dart';
import '../sync/sync_service.dart';
import 'notification_service.dart';

class PushService {
  PushService._();

  static final PushService instance = PushService._();

  bool _ready = false;
  String? _token;
  StreamSubscription<String>? _refresh;
  StreamSubscription<RemoteMessage>? _foreground;
  StreamSubscription<RemoteMessage>? _opened;

  String get _platform {
    return defaultTargetPlatform == TargetPlatform.iOS ? 'ios' : 'android';
  }

  Future<void> init() async {
    if (_ready) return;
    try {
      await Firebase.initializeApp();
      _ready = true;
    } on Object catch (error) {
      if (kDebugMode) debugPrint('[Push] init: $error');
    }
  }

  Future<void> register() async {
    if (!_ready) return;
    try {
      final messaging = FirebaseMessaging.instance;
      final token = await messaging.getToken();
      if (token != null) await _upload(token);
      _refresh ??= messaging.onTokenRefresh.listen(_upload);
      _foreground ??= FirebaseMessaging.onMessage.listen(_onForeground);
      _opened ??= FirebaseMessaging.onMessageOpenedApp.listen(
        (_) => NotificationService.instance.openInbox(),
      );
    } on Object catch (error) {
      if (kDebugMode) debugPrint('[Push] register: $error');
    }
  }

  Future<void> unregister() async {
    if (!_ready) return;
    final token = _token;
    _token = null;
    await _refresh?.cancel();
    await _foreground?.cancel();
    await _opened?.cancel();
    _refresh = null;
    _foreground = null;
    _opened = null;
    try {
      if (token != null) {
        await getIt<Dio>().delete<dynamic>(
          '/rest/v1/device_tokens',
          queryParameters: {'token': 'eq.$token'},
        );
      }
      await FirebaseMessaging.instance.deleteToken();
    } on Object catch (error) {
      if (kDebugMode) debugPrint('[Push] unregister: $error');
    }
  }

  Future<void> _upload(String token) async {
    if (!AppSession.instance.isSignedIn) return;
    try {
      await getIt<Dio>().post<dynamic>(
        '/rest/v1/rpc/register_device_token',
        data: {'p_token': token, 'p_platform': _platform},
      );
      _token = token;
    } on Object catch (error) {
      if (kDebugMode) debugPrint('[Push] upload: $error');
    }
  }

  void _onForeground(RemoteMessage message) {
    SyncService.instance.nudge();
    final notification = message.notification;
    final title = notification?.title;
    if (title == null || title.isEmpty) return;
    final type = NotificationType.fromKey(
      (message.data['type'] as String?) ?? 'general',
    );
    if (!NotificationStore.isAllowed(type)) return;
    unawaited(
      NotificationService.instance.show(
        title: title,
        body: notification?.body ?? '',
      ),
    );
  }
}
